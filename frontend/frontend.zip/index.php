<?php
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
?>
<!doctype html>
<html lang="it">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Piazzetta Madness - Torneo di Basket 5vs5 Porto Potenza Picena</title>
    <meta name="description" content="Piazzetta Madness è il torneo di basket 5vs5 più duro dell'asfalto. Raduna la tua squadra, scendi in campo e conquista la gloria. Estate 2026, Porto Potenza Picena." />
    <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
    <link rel="icon" href="/logo.png" type="image/png" />
    <link rel="preconnect" href="https://images.unsplash.com" crossorigin />
    <link
      rel="preload"
      as="image"
      href="https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&q=80&w=1920"
      fetchpriority="high"
    />
    <script type="module" crossorigin src="/assets/index-C-Pczyno.js"></script>
    <link rel="modulepreload" crossorigin href="/assets/vendor-react-CD95ech9.js">
    <link rel="modulepreload" crossorigin href="/assets/vendor-motion-BN4VwkjY.js">
    <link rel="modulepreload" crossorigin href="/assets/vendor-icons-R042lLGu.js">
    <link rel="stylesheet" crossorigin href="/assets/index-DDspvUP2.css">
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
