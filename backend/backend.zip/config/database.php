<?php
// ============================================================
// api/config/database.php
// Credenziali DB Aruba — NON committare su Git.
// ============================================================

declare(strict_types=1);

define('DB_HOST',    '31.11.39.155');
define('DB_NAME',    'Sql1938817_1');   // DB principale con struttura C# tabellone
define('DB_USER',    'Sql1938817');
define('DB_PASS',    'L3QB?%2s%96_5ih');
define('DB_CHARSET', 'utf8mb4');

// API key master (usata per creare il primo api_user via script CLI).
// Non esposta su nessun endpoint pubblico.
define('MASTER_API_KEY', 'pm_2026_7f9c2a41b8d34e60a6c9f31d2e8b57a4');

// Edizione attiva forzata (override del campo status nel DB).
// Imposta un ID > 0 per forzare un'edizione specifica, 0 per usare status='Active' dal DB.
define('ACTIVE_EDITION_ID', 0);

function get_pdo(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = 'mysql:host=' . DB_HOST
         . ';dbname=' . DB_NAME
         . ';charset=' . DB_CHARSET;

    $opts = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+00:00', NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $opts);
    } catch (PDOException $e) {
        error_log('[PiazzettaMadness] DB error: ' . $e->getMessage());
        http_response_code(503);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['error' => 'Database non disponibile', 'code' => 503]);
        exit;
    }

    return $pdo;
}
