<?php
// ============================================================
// api-ocr/config/database.php
// NON committare — contiene credenziali e token segreto.
// Copiare questo file su Aruba in api-ocr/config/ e compilare.
// ============================================================

define('DB_HOST',     '31.11.39.155');
define('DB_PORT',     3306);
define('DB_NAME',     'Sql1938817_1');
define('DB_USER',    'Sql1938817');
define('DB_PASS',    'L3QB?%2s%96_5ih');
define('DB_CHARSET',  'utf8mb4');

// Token segreto condiviso con l'app C# (appsettings.json → ocrApi.token)
define('OCR_API_TOKEN', 'pm_2026_7f9c2a41b8d34e60a6c9f31d2e8b57a4');

// ── Singleton PDO ─────────────────────────────────────────
function get_pdo(): PDO
{
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
    );
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}
